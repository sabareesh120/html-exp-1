<!DOCTYPE html>
<html>
    <head>
        <title>Controller</title>
        <h2 style="font-family: Arial, Helvetica, sans-serif;">Hey, hi we have found that you've clicked somthing from the Gadget picture.</h2>
    </head>
    <body>
        <p style="font-family: Arial, Helvetica, sans-serif; font-weight: bold;">So, you've clicked on to an Controller to know about it's Information.</p>
        <h3 style="font-family: Arial, Helvetica, sans-serif;">The Controller ↓</h3>
        <img src="https://m.media-amazon.com/images/I/61IG46p-yHL._SL1500_.jpg" length="70%" width="40%" alt="controller">
        <p style="font-family: Arial, Helvetica, sans-serif;">A controller, in a computing context, is a hardware device or a software program that manages or directs the flow of data between two entities. In computing, controllers may be cards, microchips or separate hardware devices for the control of a peripheral device.</p>
        <p style="font-family: Arial, Helvetica, sans-serif;"><b>Advantages of Controlling in the Organisation - Need Importance : </b><br>&emsp;I-Control ensures optimum utilisation of resources.
        <br>&emsp;II-Control minimises deviations.<br>&emsp;III-Control motivates employees.<br>&emsp;IV-And many more...</p>
    </body>
</html>
