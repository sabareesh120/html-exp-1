<!DOCTYPE html>
<html>
    <head>
        <title>Mobile</title>
        <h2 style="font-family: Arial, Helvetica, sans-serif;">Hey, hi we have found that you've clicked somthing from the Gadget picture.</h2>
    </head>
    <body>
        <p style="font-family: Arial, Helvetica, sans-serif; font-weight: bold;">So, you've clicked on to an Mobile Phone to know about it's Information.</p>
        <h3 style="font-family: Arial, Helvetica, sans-serif;">The Mobile ↓</h3>
        <img src="https://i.gadgets360cdn.com/products/large/motorola-edge-30-pro-657x800-1645713862.jpg" length="70%" width="40%" alt="Mobile">
        <p style="font-family: Arial, Helvetica, sans-serif;">A mobile phone is a wireless handheld device that allows users to make and receive calls. While the earliest generation of mobile phones could only make and receive calls, today's mobile phones do a lot more, accommodating web browsers, games, cameras, video players and navigational systems.</p>
        <p style="font-family: Arial, Helvetica, sans-serif;"><b>The following are some of the other key features of a smartphone : </b><br>&emsp;I-The ability to sync more than one email account to a device.
        <br>&emsp;II-Wireless synchronization with other devices, such as laptop or desktop computers.<br>&emsp;III-A hardware or software-based QWERTY keyboard.<br>&emsp;IV-And many more...</p>
    </body>
</html>
