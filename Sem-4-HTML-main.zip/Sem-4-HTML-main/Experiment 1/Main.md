<!DOCTYPE html>
<html>
    <head>
        <title>Exp 1 Page 1</title>
    </head>
    <body>
        <h1 style="font-family: Verdana, Geneva, Tahoma, sans-serif;">The Experiment number one made on Sunday - 22nd Jan of 2023</h1>
        <h2 style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Here we are gonna display the Picture of the Electronic Gadgets used in Modern times</h2>
        <p style="font-size:large; font-family: Verdana, Geneva, Tahoma, sans-serif; font-weight: bold;">The Pictures of the Gadgets ↓ </p>
        <img src="D:\DOWNLOADS\stds\Sem 4\IP\LABS\Exp 1\pics.png" alt="gadgets" usemap="#mps">
        <map name="mps">
            <area shape="rect" coords="90,371,183,270" alt="Mobile" href="file:///D:/CODING/Visual%20studio/VS%20Code%20-%20HTML%20Language/Exp%201/mob.html" target="_blank">
            <area shape="rect" coords="183,250,5,154" alt="Keyboard" href="file:///D:/CODING/Visual%20studio/VS%20Code%20-%20HTML%20Language/Exp%201/key.html" target="_blank">
            <area shape="poly" coords="371,288,369,264,400,210,423,206,433,215,465,222,480,218,497,228,497,304,482,315,456,286,418,274,375,290" alt="Controller" href="file:///D:/CODING/Visual%20studio/VS%20Code%20-%20HTML%20Language/Exp%201/cont.html" target="_blank">
        </map>
        <p style="font-family: Verdana, Geneva, Tahoma, sans-serif; font-size: medium;"> From the above Picture of the Gadgets click any of the 3 Devices(Mobile, Keyboard, or Controller) to view its Information.</p>
    </body>
</html>
