<!DOCTYPE html>
<html>
    <head>
        <title>Keyboard</title>
        <h2 style="font-family: Arial, Helvetica, sans-serif;">Hey, hi we have found that you've clicked somthing from the Gadget picture.</h2>
    </head>
    <body>
        <p style="font-family: Arial, Helvetica, sans-serif; font-weight: bold;">So, you've clicked on to an Keyboard to know about it's Information.</p>
        <h3 style="font-family: Arial, Helvetica, sans-serif;">The Keyboard ↓</h3>
        <img src="https://m.media-amazon.com/images/I/71aARXewm6L._SL1500_.jpg" length="70%" width="40%" alt="Keyboard">
        <p style="font-family: Arial, Helvetica, sans-serif;">A keyboard is for putting information including letters, words and numbers into your computer. You press the individual buttons on the keyboard when you type. The number keys across the top of the keyboard are also found on the right of the keyboard. The letter keys are in the centre of the keyboard.</p>
        <p style="font-family: Arial, Helvetica, sans-serif;"><b>The keys on your keyboard can be divided into several groups based on function : </b><br>&emsp;I-Typing (alphanumeric) keys. These keys include the same letter, number, punctuation, and symbol keys found on a traditional typewriter.
        <br>&emsp;II-keyboard is used for recepticle for anger and frustration techniques.<br>&emsp;III-key board is used for Seating, most notably for those of the feline persuasion.<br>&emsp;IV-And many more...</p>
    </body>
</html>
